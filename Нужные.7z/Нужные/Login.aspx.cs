﻿using System;
using System.Web;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
   
	protected void Page_Load(object sender, EventArgs e)
	{
   //     var grisha = Page.User.Identity.Name;
    //    Response.Write("<script>alert('"+grisha+"')</script>");
     //   Response.Redirect("Default.aspx");
		string provider = Membership.Provider.Name;
		// Отображать элементы в зависимости от того, начальная это загрузка или она произошла после изменения/восстановления пароля
		var mode = "login";

		if (!String.IsNullOrEmpty(Request.QueryString["mode"]))
			mode = Request.QueryString["mode"];
		else if (ViewState["mode"] != null)
			mode = (string)ViewState["mode"];
		setMode(mode);
	}

	private void setMode(string mode)
	{
		// спрятать всё
		Login1.Visible = false;

		switch (mode)
		{
			case "login":
				setLoginVisible(true);
				break;
		}
	}


	private void setLoginVisible(bool visible)
	{
        //Create Cookies with user
        //HttpCookie cookie = new HttpCookie("user_name");
        //cookie.Value = Login1.UserName.ToString();
        //DateTime dtNow = DateTime.Now;
        //TimeSpan tsMinute = new TimeSpan(0, 1, 0, 0);
        //cookie.Expires = dtNow + tsMinute;
        //Response.Cookies.Add(cookie);
        //FormsAuthentication.SetAuthCookie(Login1.UserName, false);
        //Context.Response.Write(Login1.UserName);


	    string a = Login1.UserName;
		Login1.Visible = visible;
        FormsAuthentication.SetAuthCookie(a, false);
		// Открыть файл web.config для клиентского модуля
		var config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~/");
		// Найти в файле web.config раздел <membership> (вернёт валидный раздел, даже если <membership> и не был прописан в файле)
		var membSection = (System.Web.Configuration.MembershipSection)config.GetSection("system.web/membership");
	}

	protected void Login1_LoginError(object sender, EventArgs e)
	{
		var user = Membership.GetUser(Login1.UserName);
		// Проверить существование учётной записи пользователя; если учётная запись существует, уточнить, возник ли отказ из-за её блокирования?
		if (user != null)
		{
			if (user.IsLockedOut)
			{
				Login1.FailureText = String.Format(System.Globalization.CultureInfo.InvariantCulture, "Учётная запись пользователя {0} заблокирована. Пожалуйста, обратитесь за технической поддержкой по тел. 52-50-62.",
					Login1.UserName);
			}

		}

	}
	protected void Login1_PreRender(object sender, EventArgs e)
	{
          bool f1 = false;
        ////Create Cookies with user
        //HttpCookie cookie = new HttpCookie("user_name");
        //cookie.Value = Login1.UserName;
        //DateTime dtNow = DateTime.Now;
        //TimeSpan tsMinute = new TimeSpan(0, 1, 0, 0);
        //cookie.Expires = dtNow + tsMinute;
        //Response.Cookies.Add(cookie);
        //FormsAuthentication.SetAuthCookie(Login1.UserName, false);

        f1 = Membership.ValidateUser(Login1.UserName, Login1.Password);
        if (f1)
	    {
	        FormsAuthentication.SetAuthCookie(Login1.UserName, false);
	        var aset = Roles.GetRolesForUser(Login1.UserName);
	    }
	}
	protected void Login1_LoggedIn(object sender, EventArgs e)
	{
        //Create Cookies with user
      
	}
}
